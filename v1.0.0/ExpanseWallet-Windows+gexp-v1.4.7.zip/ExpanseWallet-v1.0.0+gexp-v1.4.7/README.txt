ExpanseWallet v1

This wallet will work with gexp.exe in the same directory or if gexp.exe is run from another directory.

If you copy gexp.exe into the same directory as the ExpanseWallet.exe
the ExpanseWallet will start gexp.exe for you with no Dos window.

If you run gexp.exe from another directory just start it the same way you always do and then run ExpanseWallet.exe